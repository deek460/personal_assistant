/// Toggle to show raw model output or formatted output in chat UI
const bool kShowRawModelOutput = true;