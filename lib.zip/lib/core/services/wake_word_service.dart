import 'dart:async';
import 'package:porcupine_flutter/porcupine_manager.dart';

typedef WakeWordDetectedCallback = void Function();

class WakeWordService {
  WakeWordService._privateConstructor();
  static final WakeWordService _instance = WakeWordService._privateConstructor();
  factory WakeWordService() => _instance;

  PorcupineManager? _porcupineManager;
  bool _isListening = false;
  WakeWordDetectedCallback? _onWakeWord;

  /// Initialize Porcupine with list of keyword files
  Future<void> initialize({
    required String accessKey,
    required List<String> keywordAssetPaths,
    required WakeWordDetectedCallback onWakeWord,
  }) async {
    _onWakeWord = onWakeWord;

    try {
      _porcupineManager = await PorcupineManager.fromKeywordPaths(
        accessKey,
        keywordAssetPaths,
        _wakeWordCallback,
        // You can optionally specify sensitivities or model path here
      );
    } catch (e) {
      print('Error initializing Porcupine: $e');
      rethrow;
    }
  }

  Future<void> startListening() async {
    if (_isListening || _porcupineManager == null) return;
    try {
      await _porcupineManager!.start();
      _isListening = true;
    } catch (e) {
      print('Error starting Porcupine: $e');
    }
  }

  Future<void> stopListening() async {
    if (!_isListening || _porcupineManager == null) return;
    try {
      await _porcupineManager!.stop();
      _isListening = false;
    } catch (e) {
      print('Error stopping Porcupine: $e');
    }
  }

  void _wakeWordCallback(int keywordIndex) {
    print('Wake word detected with index: $keywordIndex');
    _onWakeWord?.call();
  }

  bool get isListening => _isListening;

  Future<void> dispose() async {
    await _porcupineManager?.delete();
    _isListening = false;
  }
}
