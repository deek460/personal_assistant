import 'package:get_it/get_it.dart';

final GetIt serviceLocator = GetIt.instance;

Future<void> setupServiceLocator() async {
  // Register services here later
  // For now, we'll keep it empty
}
